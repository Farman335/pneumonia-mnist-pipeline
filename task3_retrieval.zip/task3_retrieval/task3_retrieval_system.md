# Task 3 Retrieval System  
**Content-Based Image Retrieval for PneumoniaMNIST**

**Author:** FARMAN  
**Date:** February 21, 2026  
**Challenge:** AlfaisalX Postdoctoral Technical Challenge – AI Medical Imaging

## Embedding Model Selection and Justification

**Selected Model:** Vision Transformer (ViT-B/16) pre-trained on ImageNet-1K (torchvision)  
- Extracts 768D CLS token embeddings by replacing the classification head with Identity().

**Justification:**  
While medical-specific encoders (e.g., BioViL-T, MedCLIP, PMC-CLIP) are recommended for optimal medical feature capture, ViT-B/16 was selected as a strong, general-purpose model with excellent transfer learning capabilities demonstrated in medical imaging (including >90% accuracy on CXR classification tasks). It effectively captures medically relevant visual features such as textures, opacities, and global lung patterns via self-attention — well-suited to the low-resolution pediatric CXRs in PneumoniaMNIST.  

Key advantages in this context:  
- Direct reuse of the same ViT-B/16 backbone as Task 1 (91.51% accuracy, 97.98% recall, 0.9818 AUC), ensuring consistency across the pipeline.  
- Efficient for the small test set (624 images); 768D embeddings balance expressiveness and search speed.  
- Pre-training on diverse natural images provides robust generalization despite not being medically specialized.  

Alternatives like MedCLIP were considered for native text-to-image support, but ViT was prioritized for simplicity, Task 1 alignment, and sufficient performance without fine-tuning for this baseline CBIR system.

## Vector Database Implementation Details

**Library:** FAISS (Facebook AI Similarity Search) with `IndexFlatL2` (exact Euclidean / L2 distance).  

- **Why FAISS?** Extremely efficient for exact nearest-neighbor search on small-to-medium datasets (no approximation needed for 624 vectors). Supports CPU/GPU execution, lightweight compared to persistent databases like ChromaDB or Pinecone.  
- **Index Construction:** All 768D float32 embeddings from the test set are added to the index.  
- **Storage:** Saved as binary file `faiss_index.index` and loaded via `faiss.read_index()`.  
- **Distance Metric:** L2 (Euclidean) – standard and effective for normalized ViT embeddings.  
- **Scale & Performance:** 624 vectors; typical query time <1 ms on CPU.

## Retrieval System Architecture and Usage Instructions

**Architecture Overview:**
- **Embedding Extraction:** Preprocessed images (224×224, ImageNet normalized) are passed through ViT-B/16 (heads removed) to obtain 768D CLS token embeddings.  
- **Indexing:** FAISS `IndexFlatL2` stores all test-set embeddings; labels and original images kept separately for evaluation and visualization.  
- **Image-to-Image Search:** Query image → embed → FAISS k-NN search (exclude self-match) → return top-k indices and distances.  
- **Text-to-Image Search:** Not implemented (ViT is image-only). Extension path: replace with MedCLIP or similar multimodal encoder to embed text queries and search against image embeddings.  
- **CLI Interface:** Standalone script `image_search.py` (example usage: `python image_search.py --query_idx 42 --k 5`).  
- **Full Pipeline:** End-to-end execution in notebook `task_3_retrieval (1).ipynb`. Required dependencies:  
  ```bash
